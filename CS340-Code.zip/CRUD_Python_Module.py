# ------------------------------------------------
# CRUD_Python_Module.py
# ------------------------------------------------
# CRUD Operations for Animal collection in MongoDB
#
# Template By: SNHU
# Author: Justin Crouch
# Last Edited: 2025-10-02
# ------------------------------------------------

# Import classes to work with MongoDB
from pymongo import MongoClient 
from bson.objectid import ObjectId 

# AnimalShelter class to handle CRUD operations on
# the animals collection within the aac database
class AnimalShelter(object): 
    """ CRUD operations for Animal collection in MongoDB """ 

    # Initialize AnimalShelter class by connecting to database
    def __init__(self, username, password):
        # Verify username parameter exists and is a string before initializing database connection
        # Username should be a string
        if type(username) != type(''):
            raise Exception("Cannot log in to database without a username string")
        
        # Verify password parameter exists and is a string before initializing database connection
        # Password should be a string
        if type(password) != type(''):
            raise Exception("Cannot log in to database without a password string")
            
        # Initializing the MongoClient. This is hard-wired to use the aac 
        # database and animals collection. 
        # 
        # Connection Variables 
        # 
        USER = username
        PASS = password 
        HOST = 'localhost' 
        PORT = 27017 
        DB = 'aac' 
        COL = 'animals' 
        # 
        # Initialize Connection 
        #
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT)) 
        self.database = self.client['%s' % (DB)] 
        self.collection = self.database['%s' % (COL)] 

    # Create a method to return the next available record number for use in the create method
            
    # Method to insert an existing dictionary of data into the database
    def create(self, data):
        # Verify data parameter exists before inserting into 'animals' collection
        # Data should be a dictionary
        if data is None: 
            raise Exception("Nothing to save, because data parameter is empty")
        
        # Catch InsertManyResult object generated from the insert operation
        created = self.database.animals.insert_one(data)
            
        # Return true if data was successfully inserted; false otherwise
        create_successful = self.database.animals.find_one({'_id' : created.inserted_id}) is not None
        return create_successful

    # Method to find and return a list of data from the database from an existing query
    def read(self, query):
        # Verify query parameter exists before looking into 'animals' collection
        # Query should be a dictionary
        if query is None: 
            raise Exception("Nothing to find, because query parameter is empty")
        
        # Catch Cursor object generated from the find operation
        results = self.database.animals.find(query)
            
        # Return list of found results
        return results.to_list()
    
    # Method to update data given a query and a specific operation for the update
    def update(self, query, operation):
        # Verify query parameter exists before updating 'animals' collection
        # Query should be a dictionary
        if query is None: 
            raise Exception("Nothing to update, because query parameter is empty")
            
        # Verify operation parameter exists before updating 'animals' collection
        # Operation should be a dictionary
        if operation is None: 
            raise Exception("Nothing to update, because operation parameter is empty")
        
        # Catch UpdateResult object generated from the update operation
        result = self.database.animals.update_many(query, operation)
        
        # Return number of documents actually modified
        return result.modified_count
    
    def delete(self, query):
        # Verify query parameter exists before updating 'animals' collection
        # Query should be a dictionary
        if query is None: 
            raise Exception("Nothing to update, because query parameter is empty")
        
        # Catch DeleteResult object generated from the delete operation
        result = self.database.animals.delete_many(query)
        
        return result.deleted_count